program HandRat3;

(*
 * program HandRat3 (for Delphi .NET)
 * Copyright 2005, Charles A. Appel Jr.
 *)

{%DelphiDotNetAssemblyCompiler '$(SystemRoot)\microsoft.net\framework\v1.1.4322\system.drawing.dll'}

uses
  Forms,
  RATHAND3 in 'RATHAND3.PAS' {frmRateHands},
  caaPSCrd in 'caaPSCrd.pas',
  CAAPSDCK in 'CAAPSDCK.PAS',
  CAAPS3CH in 'CAAPS3CH.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrmRateHands, frmRateHands);
  Application.Run;
end.
