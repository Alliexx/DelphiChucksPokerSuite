program HandRat4;

(*
 * program HandRat4 (for Delphi .NET)
 * Copyright 2005, Charles A. Appel Jr.
 *)

{%DelphiDotNetAssemblyCompiler '$(SystemRoot)\microsoft.net\framework\v1.1.4322\system.drawing.dll'}

uses
  Forms,
  RATHAND4 in 'RATHAND4.PAS' {frmRateHands},
  caaPSCrd in 'caaPSCrd.pas',
  CAAPSDCK in 'CAAPSDCK.PAS',
  CAAPS4CH in 'CAAPS4CH.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrmRateHands, frmRateHands);
  Application.Run;
end.
