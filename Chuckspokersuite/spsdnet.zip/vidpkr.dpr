program vidpkr;

(*
 * program vidpkr ( for Delphi .NET )
 * copyright 2005, Charles A. Appel Jr.
 *)

{%DelphiDotNetAssemblyCompiler '$(SystemRoot)\microsoft.net\framework\v1.1.4322\system.drawing.dll'}

uses
  Forms,
  vpkrmain in 'vpkrmain.pas' {formMain},
  CAAPS5CH in 'CAAPS5CH.PAS',
  caaPSCrd in 'caaPSCrd.pas',
  CAAPSDCK in 'CAAPSDCK.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TformMain, formMain);
  Application.Run;
end.
