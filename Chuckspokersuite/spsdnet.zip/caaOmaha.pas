unit caaOmaha;

(*
  Unit caaOmaha for Delphi 1 through Delphi 2005
  Version 1.0.0
  Copyright 2005, Charles A. Appel Jr.

  Purpose:
    This is a helper/utility unit designed to make programming Omaha poker
      games and simulations easier.
     1) Exports an Omaha hand type.
     2) Exports procedures to set the high and low ratings of Omaha hands.
     3) Exports functions to return the five card hand name in an Omaha hand.

    Omaha is a bit tricky. Each player recieves four hole cards and five cards
      are face up in the center of the table. These are the common cards. The
      player's actual hand consists of any two hole cards combined with any
      three of the common cards. This makes the game more confusing than Texas
      Hold'em.

  History:
    10-10-2005 -
      Unit created. Testing begun.

    10-12-2005 -
      Aditional testing.
 *)

interface

uses
  caaPSCrd, caaPS5CH;

type
  { Card Arrays }
  TcaaOmahaHoleCardArray = array[1..4] of TcaaCard;

  { Omaha Hand }
  TcaaOmahaHand = record
    HoleCards: TcaaOmahaHoleCardArray;
    CommonCards: Tcaa5CardArray;
    HighRating : Tcaa5CardHandRating;
    LowRating: Tcaa5CardHandRating;
  end; 

{ Omaha: Helper routines ----------------------------------------------------- }
{ Hand rating procedures for Omaha Hands }
procedure caaOmahaSetHighValue( var Hand: TcaaOmahaHand );
procedure caaOmahaSetLowValue( var Hand: TcaaOmahaHand );

{ Hand name functions for Omaha Hands }
function caaOmahaGetHighHandName( const Hand: TcaaOmahaHand ): Tcaa5CardHandName;
function caaOmahaGetLowHandName( const Hand: TcaaOmahaHand ): Tcaa5CardHandName;

implementation

{ Omaha: Helper routines ----------------------------------------------------- }
{ Hand rating procedures for Omaha Hands ------------------------------------- }
{ procedure caaOmahaSetHighValue
  Expects: Hand: A valid hand of 7 cards.
  Returns: The same hand with the high rating set. }
procedure caaOmahaSetHighValue( var Hand: TcaaOmahaHand );
var
  hole1,
  hole2,
  common1,
  common2,
  common3: integer; { card positions }
  tmpHand: Tcaa5CardHand;
  tmpHighRating: Tcaa5CardHandRating;
begin
  tmpHighRating := 0;
  { loop through the hole cards }
  for hole1 := 1 to 3 do
    for hole2 := hole1 + 1 to 4 do
    begin
      tmpHand.Cards[1] := Hand.HoleCards[hole1];
      tmpHand.Cards[2] := Hand.HoleCards[hole2];
      for common1 := 1 to 3 do
        for common2 := common1 + 1 to 4 do
          for common3 := common2 + 1 to 5 do
          begin
            tmpHand.Cards[3] := Hand.CommonCards[common1];
            tmpHand.Cards[4] := Hand.CommonCards[common2];
            tmpHand.Cards[5] := Hand.CommonCards[common3];
            caa5CardSetHighValue( tmpHand );
            if tmpHand.Rating > tmpHighRating then
              tmpHighRating := tmpHand.Rating;
          end;
    end; { for c2 }
    Hand.HighRating := tmpHighRating;
end;


{ procedure caaOmahaSetLowValue
  Expects: Hand: A valid hand of 7 cards.
  Returns: The same hand with the low rating set. }
procedure caaOmahaSetLowValue( var Hand: TcaaOmahaHand );
var
  hole1,
  hole2,
  common1,
  common2,
  common3: integer; { card positions }
  tmpHand: Tcaa5CardHand;
  tmpLowRating: Tcaa5CardHandRating;
begin
  tmpLowRating := $F00000;
  { loop through the hole cards }
  for hole1 := 1 to 3 do
    for hole2 := hole1 + 1 to 4 do
    begin
      tmpHand.Cards[1] := Hand.HoleCards[hole1];
      tmpHand.Cards[2] := Hand.HoleCards[hole2];
      for common1 := 1 to 3 do
        for common2 := common1 + 1 to 4 do
          for common3 := common2 + 1 to 5 do
          begin
            tmpHand.Cards[3] := Hand.CommonCards[common1];
            tmpHand.Cards[4] := Hand.CommonCards[common2];
            tmpHand.Cards[5] := Hand.CommonCards[common3];
            caa5CardSetLowValue( tmpHand );
            if tmpHand.Rating < tmpLowRating then
              tmpLowRating := tmpHand.Rating;
          end;
    end; { for c2 }
    Hand.LowRating := tmpLowRating;
end;


{ Hand name functions for Omaha Hands ---------------------------------------- }
{ function caaOmahaGetHighHandName
  Expects: A valid Omaha hand with the high rating set. It is the high rating
           that is used to build the hand name - not the card array.
  Returns: The name of the hand based on the HighRating. }
function caaOmahaGetHighHandName( const Hand:TcaaOmahaHand ): Tcaa5CardHandName;
var
  tmpHand: Tcaa5CardHand;
begin
  tmpHand.Rating := Hand.HighRating;
  result := caa5CardGetHandName( tmpHand );
end;


{ function caaOmahaGetLowHandName
  Expects: A valid Omaha hand with the low rating set. It is the low rating
           that is used to build the hand name - not the card array.
  Returns: The name of the hand based on the LowRating. }
function caaOmahaGetLowHandName( const Hand: TcaaOmahaHand ): Tcaa5CardHandName;
var
  tmpHand: Tcaa5CardHand;
begin
  tmpHand.Rating := Hand.LowRating;
  result := caa5CardGetHandName( tmpHand );
end;

end.
