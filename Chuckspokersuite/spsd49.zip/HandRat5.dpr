program HandRat5;

(*
 * program HandRat5 for Delphi 4 through 2005 (32-Bit Native)
 * Copyright 2005, Charles A. Appel Jr.
 *)

uses
  Forms,
  RATHAND5 in 'RATHAND5.PAS' {frmRateHands},
  caaPSCrd in 'caaPSCrd.pas',
  caaPSDck in 'CAAPSDCK.PAS',
  caaPS5CH in 'CAAPS5CH.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrmRateHands, frmRateHands);
  Application.Run;
end.
