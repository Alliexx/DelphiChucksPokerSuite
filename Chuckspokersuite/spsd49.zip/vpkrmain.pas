unit vpkrmain;

(*
 * unit vpkerMain for Delphi 4 through 2005 (32-Bit Native)
 * Copyright 2005, Charles A. Appel Jr.
 *
 * Demo program for the Poker Suite.
 * This program is a minimalist version of a video poker game.
 *)

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

type
  TformMain = class(TForm)
    btnBet: TButton;
    btnDraw: TButton;
    lblBet: TLabel;
    lblCredits: TLabel;
    lblInfo: TLabel;
    lblHandName: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure btnBetClick(Sender: TObject);
    procedure btnDrawClick(Sender: TObject);
  private
    { Private declarations }
    cardImages: array[1..5] of TImage;
    cardLabels: array[1..5] of TLabel;
    procedure CardClick(Sender: TObject);
  public
    { Public declarations }
  end;

var
  formMain: TformMain;

implementation

{$R *.DFM}
{$R CACARDS03.RES}

uses
  caaPSCrd, caaPSDck, caaPS5CH;

const
  { minimum rating of a Jacks or Better poker hand }
  caa5CardJacksOrBetter  = $1BB432; { 1815602 }

  { indexes into payout array }
  poNoPair        = 0;
  poJacks         = 1;
  poTwoPair       = 2;
  poThreeKind     = 3;
  poStraight      = 4;
  poFlush         = 5;
  poFullHouse     = 6;
  poFourKind      = 7;
  poStraightFlush = 8;
  poRoyalFlush    = 9;

  { lblInfo Messages - with leading space }
  PlaceBetCaption    = ' Place a Bet.';
  HoldDrawCaption    = ' Click Cards to Hold, then Draw.';

  { lblBet and lblCredit prefixes - with leading space }
  BetLabelCaption    = ' Bet: ';
  CreditLabelCaption = ' Credits: ';

  { lblHandName winning and losing prefixes - no leading space }
  LoserMessage       = 'Too Bad! - ';
  WinnerMessage      = 'You Won! - ';
  
type
  { array type to hold payouts }
  TPayOut = array[poNoPair..poRoyalFlush] of integer;

const
  { holds standard payouts for a five coin bet on 9-6 Jacks or Better. }
  StdPayOuts: TPayout = ( 0, 5, 10, 15, 20, 30, 45, 125, 250, 1250 );

{ video poker game definition }
type
  { TGameMode defines the current mode the game is in.
      this is used to determine whether clicking on a card
        image will display or undisplay a Held label.
      The mode is set by the Bet and Draw button click events.
      }
  TGameMode = (betMode, drawMode);

  { TvidPokerGame is a record containing six fields that encapsulate
      the game information. These are:
      Deck    : The deck of cards used in the game.
      Hand    : The hand of cards used.
      Bet     : The amount of the current bet. Always 0 or 5.
      Credits : The current credits the player has.
      Payouts : The list of payout amounts for all hand types.
      Mode    : The mode the game is currently in. }
  TvidPokerGame = record
    Deck    : TcaaCardDeck;
    Hand    : Tcaa5CardHand;
    Bet     : integer;
    Credits : integer;
    PayOuts : TPayOut;
    Mode    : TGameMode;
  end;

var
  Game: TvidPokerGame;

{ function ImageName
  Expects: A Card of type TcaaCard.
  Returns: The resource name of the card displayed based on its Rank and Suit
             attributes. The format returned is compatible with all three
             32-bit card resource files supplied with the library. }
function ImageName(Card: TcaaCard): string;
begin
  { first, create the suit portion of the name with underbar }
  case Card.CardSuit of
    caaClubs    : Result := 'CLUB_';
    caaDiamonds : Result := 'DIAMOND_';
    caaHearts   : Result := 'HEART_';
    caaSpades   : Result := 'SPADE_';
  end;

  { next add the rank information for the ace through ten,
    the rank number should be preceded by a zero. the line
    below does this for two through ten... }
  if Card.CardRank < caaTen then Result := Result + '0';

  { ...but aces default to high, so they are a special case.
    if we don't compensate, we can return results like 'SPADE_14'.
    the else clause handles Jacks through Kings. }
  if Card.CardRank = caaAceHigh then
    Result := Result + '01'
  else
    Result := Result + intToStr( ord( Card.CardRank ) + 1 );
end;

{ procedure CardClick
  Does: Click event for all card images.
        If in draw mode, allows player to toggle hold status by
        making the card labels visible or inivisible. }
procedure TformMain.CardClick(Sender: TObject);
begin
  { in betting mode, clicking on the cards should have no effect }
  if Game.Mode = betMode then exit;
  with Sender as TImage do
    CardLabels[Tag].Visible := not CardLabels[Tag].Visible;
end;

{ procedure FormCreate
  Does: Initializes everything. }
procedure TformMain.FormCreate(Sender: TObject);
var
  i,
  cardLeft,
  cardTop,
  cardWidth,
  cardHeight,
  cardSpace,
  labelTop,
  labelHeight: integer;
begin
  { game data - fill the deck and set default starting values. }
  caaBuildCardDeck( Game.Deck );
  Game.Credits := 100;
  Game.Bet     := 0;
  Game.PayOuts := StdPayOuts;
  Game.Mode    := betMode;

  { form information }
  formMain.Width  := 604;
  formMain.Height := 284;

  { card position information }
  cardWidth  := 100;  { width of a card image }
  cardHeight := 140;  { height of a card image }
  cardSpace  := 16;   { space between card images }
  cardTop    := 8;    { top position of all card images }
  cardLeft   := 17;   { left position of first card imagae }

  { information labels position and display information }
  lblBet.Left         := cardLeft;
  lblBet.Caption      := BetLabelCaption + '0';
  lblCredits.Left     := lblBet.Left + lblBet.Width + 4;
  lblCredits.Caption  := CreditLabelCaption + '100';
  lblInfo.Left        := cardLeft;
  lblInfo.Caption     := PlaceBetCaption;
  lblHandName.Left    := cardLeft;
  lblHandName.Caption := '';

  { card label position and size information }
  labelHeight := 24;
  labelTop    := cardTop + cardHeight;

  { game buttons }
  btnBet.Enabled  := True;
  btnDraw.Enabled := False;

  { place the images and labels }
  for i := 1 to 5 do
  begin
    cardImages[i]             := TImage.Create(formMain);
    cardImages[i].Parent      := formMain;
    cardImages[i].AutoSize    := False;
    cardImages[i].Stretch     := True;
    cardImages[i].Transparent := True;
    cardImages[i].Top         := cardTop;
    cardImages[i].Height      := cardHeight;
    cardImages[i].Width       := cardWidth;
    cardImages[i].Left        := cardLeft;
    cardImages[i].Tag         := i;
    cardImages[i].OnClick     := CardClick;
    cardImages[i].Picture.Bitmap.LoadFromResourceName(hInstance,'CARDBACK_01');

    cardLabels[i]             := TLabel.Create(formMain);
    cardLabels[i].Parent      := formMain;
    cardLabels[i].AutoSize    := False;
    cardLabels[i].Transparent := False;
    cardLabels[i].Color       := clBlue;
    cardLabels[i].Font.Color  := clAqua;
    cardLabels[i].Font.Name   := 'Courier New';
    cardLabels[i].Font.Size   := 14;
    cardLabels[i].Font.Style  := [fsBold];
    cardLabels[i].Top         := labelTop;
    cardLabels[i].Height      := labelHeight;
    cardLabels[i].Width       := cardWidth - 7;
    CardLabels[i].Left        := cardLeft + 4;
    cardLabels[i].Caption     := 'HELD';
    cardLabels[i].Alignment   := taCenter;
    cardLabels[i].Visible     := False;
    cardLabels[i].Tag         := i;

    { set position for next card }
    cardLeft := cardLeft + cardSpace + cardWidth;
  end;
end;

{ procedure FormDestroy
  Does: Frees the cardImages and cardLabels. }
procedure TformMain.FormDestroy(Sender: TObject);
var
  i: integer;
begin
  { free the controls we created }
  for i := 1 to 5 do
  begin
    CardImages[i].Free;
    CardLabels[i].Free;
  end;
end;

{ procedure btnBetClick
  Does: Removes 5 from Game.Credits.
        Sets Game.Bet to 5.
        Causes deck to be shuffled.
        Causes Hand to be dealt and displayed.
        Sets info label caption.
        Disables Bet button.
        Enables Draw button.
        Sets Game Mode to drawmode (activating click ability of images). }
procedure TformMain.btnBetClick(Sender: TObject);
var
  cd : integer;
  CardImageName: string;
  pCardName: array[0..10] of char;
begin
  { clear the hand name label }
  lblHandName.Caption := '';

  { deduct bet from credits and refresh the Credits label }
  Game.Credits       := Game.Credits - 5;
  lblCredits.Caption := CreditLabelCaption + IntToStr( Game.Credits );

  { set bet to 5 and refresh the bet label }
  Game.Bet       := 5;
  lblBet.Caption := BetLabelCaption + '5';

  { shuffle the deck and deal the first five cards from the deck }
  caaShuffleCardDeck( Game.Deck );
  for cd := 1 to 5 do
  begin
    Game.Hand.Cards[cd] := Game.Deck[cd-1];
    { display  card images }
    CardImageName := ImageName( Game.Hand.Cards[cd] );
    StrPCopy(pCardName,CardImageName);
    cardImages[cd].Picture.Bitmap.LoadFromResourceName(hInstance,pCardName);
  end;

  { refresh the player instructions and reset the game buttons }
  lblInfo.Caption := HoldDrawCaption;
  btnBet.Enabled  := False;
  btnDraw.Enabled := True;

  { set the game mode to card drawing mode.
    this allows the player to click on a card image to
      hold/unhold it. }
  Game.Mode := drawMode;
end;

{ procedure btnDrawClick
  Does: Draws cards from the deck and replaces those in the hand that aren't
          held.
        Sets all card labels to invisible.
        Passes the hand to the library for rating.
        Passes the rating to...??
        Enables the Bet Button.
        Disables the Draw Button.
        Sets the game mode to betMode (disabling the card clicks.) }
procedure TformMain.btnDrawClick(Sender: TObject);
var
  cd : integer;
  CardImageName: string;
  pCardName: array[0..10] of char;
  winStr: string;
begin
  { draw cards from the deck starting at deck position 5
    make any held labels that are visible invisible. }
  for cd := 1 to 5 do
  begin
    { if a cardLabel is not visible then the card is not held.
      and we want to replace it. }
    if not cardLabels[cd].Visible then
    begin
      { get a replacement card }
      Game.Hand.Cards[cd] := Game.Deck[cd+4];
      { display the card image }
      CardImageName := ImageName( Game.Hand.Cards[cd] );
      StrPCopy(pCardName,CardImageName);
      cardImages[cd].Picture.Bitmap.LoadFromResourceName(hInstance,pCardName);
    end
    else { label is visible - change this }
      cardLabels[cd].Visible := False;
  end;

  { get high hand rating }
  caa5CardSetHighValue( Game.Hand );

  { pay offs - if the hand is less than Jacks or Better
      prepare to display the losing message
    otherwise
      prepare to display the winning message and
      update the credits to reflect the win. }
  if Game.Hand.Rating < caa5CardJacksOrBetter then   
  begin
    winStr := LoserMessage;
  end
  else if Game.Hand.Rating < caa5CardTwoPair then 
  begin
    { Jacks or Better }
    Game.Credits := Game.Credits + Game.Payouts[poJacks];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardThreeOfAKind then
  begin
    { two pair }
    Game.Credits := Game.Credits + Game.Payouts[poTwoPair];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardStraight then
  begin
    { three of a kind }
    Game.Credits := Game.Credits + Game.Payouts[poThreeKind];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardFlush then
  begin
    { straight }
    Game.Credits := Game.Credits + Game.Payouts[poStraight];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardFullHouse then
  begin
    { flush }
    Game.Credits := Game.Credits + Game.Payouts[poFlush];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardFourOfAKind then
  begin
    { full house }
    Game.Credits := Game.Credits + Game.Payouts[poFullHouse];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardStraightFlush then
  begin
    { four of a kind }
    Game.Credits := Game.Credits + Game.Payouts[poFourKind];
    winStr := WinnerMessage;
  end
  else if Game.Hand.Rating < caa5CardRoyalFlush then
  begin
    { straight flush }
    Game.Credits := Game.Credits + Game.Payouts[poStraightFlush];
    winStr := WinnerMessage;
  end
  else
  begin
    { royal flush }
    Game.Credits := Game.Credits + Game.Payouts[poRoyalFlush];
    winStr := WinnerMessage;
  end;

  { update the display labels }
  lblBet.Caption      := BetLabelCaption + '0';
  lblInfo.Caption     := PlaceBetCaption;
  lblCredits.Caption  := CreditLabelCaption + IntToStr( Game.Credits );

  { add the hand name to the winning or losing message and display it }
  lblHandName.Caption :=
    { IntToHex( Game.Hand.Rating, 6 ) + ' ' + }
    winStr + 
    caa5CardGetHandName( Game.Hand );

  { update buttons }
  btnBet.Enabled  := True;
  btnDraw.Enabled := False;

  { restore the game mode to betting mode. this prevents
    any card clisks from displaying the hold label. }
  Game.Mode := betMode;
end;

end.
