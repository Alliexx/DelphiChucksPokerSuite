unit ratOMain;

(*
  Unit mhrOMain for Delphi 4 through Delphi 2005 (Native 32-Bit)
  Copyright 2005, Charles A. Appel Jr.

  Purpose:
    Multi-hand rating utility using Omaha hands.
    Also demonstrates use of the caaOmaha.pas helper library.
 *)

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, caaPSCrd, caaPSDck, caaPS5CH, caaOmaha;

type
  TformMain = class(TForm)
    lbxDisplay: TListBox;
    btnRandom: TButton;
    btnStraightFlushes: TButton;
    btnFourOfAKind: TButton;
    btnFullHouses: TButton;
    btnFlushes: TButton;
    btnStraights: TButton;
    btnThreeOfAKind: TButton;
    btnTwoPair: TButton;
    btnPairs: TButton;
    procedure btnRandomClick(Sender: TObject);
    procedure btnStraightFlushesClick(Sender: TObject);
    procedure btnFourOfAKindClick(Sender: TObject);
    procedure btnFullHousesClick(Sender: TObject);
    procedure btnFlushesClick(Sender: TObject);
    procedure btnStraightsClick(Sender: TObject);
    procedure btnThreeOfAKindClick(Sender: TObject);
    procedure btnTwoPairClick(Sender: TObject);
    procedure btnPairsClick(Sender: TObject);
  private
    { Private declarations }
    procedure showHand( OmahaHand: TcaaOmahaHand );
  public
    { Public declarations }
  end;

var
  formMain: TformMain;

implementation

{$R *.DFM}

{ Helper Functions ----------------------------------------------------------- }

{ function ratingToString
  Expects: A valid five card hand rating.
  Returns: The rating converted to a string in a more easily read format.
  Notes:   The hexadecimal display was confusing.
           The format is R-XXXXX, where:
              R = the hand rank value.
              - = a hyphen.
              X = the card rank.
            Card Ranks are:
              A = Ace     2 = Two    3 = Three    4 = Four
              5 = Five    6 = Six    7 = Seven    8 = Eight
              9 = Nine    T = Ten    J = Jack     Q = Queen 
              K = King
            Hand Rank Values are:
              0 = No Pair    1 = One Pair   2 = Two Pair    3 = 3 of a Kind
              4 = Straight   5 = Flush      6 = Full House  7 = 4 of a Kind
              8 = Str Flush  9 = Royal      A = 5 of a Kind }
function ratingToString( rating: Tcaa5CardHandRating ): string;
var
  fromStr,
  toStr: string;
  charPos,
  sLen: integer;
begin
  { convert rating to hexadecimal string }
  fromStr := UpperCase(IntToHex( rating, 6 ));

  { get length of string}
  sLen := Length( fromStr );

  { initialize return value  }
  toStr := fromStr[1] + '-';

  { convert remaining characters }
  for charPos := 2 to sLen do
  begin
    case fromStr[charPos] of
      '1' : toStr := toStr + 'A';
      '2' : toStr := toStr + '2';
      '3' : toStr := toStr + '3';
      '4' : toStr := toStr + '4';
      '5' : toStr := toStr + '5';
      '6' : toStr := toStr + '6';
      '7' : toStr := toStr + '7';
      '8' : toStr := toStr + '8';
      '9' : toStr := toStr + '9';
      'A' : toStr := toStr + 'T';
      'B' : toStr := toStr + 'J';
      'C' : toStr := toStr + 'Q';
      'D' : toStr := toStr + 'K';
      'E' : toStr := toStr + 'A';
    end; { case }
  end; { for }
  result := toStr;
end; { function ratingToString }

{ TformMain ------------------------------------------------------------------ }

{ procedure TformMain.showHand
  Does: Displays the High Rating and High Hand Name.
        Displays the Low Rating and Low Hand Name.
        Displays the Names of the Nine Cards.}
procedure TformMain.showHand( OmahaHand: TcaaOmahaHand );
var
  tmpStr: string;
begin
  { high hand name and rating }
  caaOmahaSetHighValue( OmahaHand );
  tmpStr :=
    'High: ' +
    ratingToString( OmahaHand.HighRating ) +
    '  (Hex:' +
    IntToHex( OmahaHand.HighRating, 6 ) +
    ')  ' +
    caaOmahaGetHighHandName( OmahaHand );
  lbxDisplay.Items.Add( tmpStr );

  { low hand name and rating }
  caaOmahaSetLowValue( OmahaHand );
  tmpStr :=
    'Low:  ' +
    ratingToString( OmahaHand.LowRating ) +
    '  (Hex:' +
    IntToHex( OmahaHand.LowRating, 6 ) +
    ')  ' +
    caaOmahaGetLowHandName( OmahaHand );
  lbxDisplay.Items.Add( tmpStr );

  { names of hole cards in order }
  lbxDisplay.Items.Add('Hole Cards:');
  tmpStr := caaGetCardName( OmahaHand.HoleCards[1] );
  lbxDisplay.Items.Add( ' 1) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.HoleCards[2] );
  lbxDisplay.Items.Add( ' 2) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.HoleCards[3] );
  lbxDisplay.Items.Add( ' 3) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.HoleCards[4] );
  lbxDisplay.Items.Add( ' 4) ' + tmpStr );

  { names of common cards in order }
  lbxDisplay.Items.Add('Common Cards:');
  tmpStr := caaGetCardName( OmahaHand.CommonCards[1] );
  lbxDisplay.Items.Add( ' 1) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.CommonCards[2] );
  lbxDisplay.Items.Add( ' 2) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.CommonCards[3] );
  lbxDisplay.Items.Add( ' 3) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.CommonCards[4] );
  lbxDisplay.Items.Add( ' 4) ' + tmpStr );
  tmpStr := caaGetCardName( OmahaHand.CommonCards[5] );
  lbxDisplay.Items.Add( ' 5) ' + tmpStr );
  lbxDisplay.Items.Add( '' );
end; { procedure showHand }


{ procedure TformMain.btnRandomClick
  Does: Generates 10 random Omaha hands. 
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnRandomClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  count: integer;
  Deck: TcaaCardDeck;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { present opening message }
  lbxDisplay.Items.Add( 'The following ten hands are randomly generated.' );
  lbxDisplay.Items.Add( '' );

  { create ten random hands }
  for count := 1 to 10 do
  begin
    { shuffle betwee each hand }
    caaShuffleCardDeck( Deck );
    CommonCards[1] := Deck[0];
    CommonCards[2] := Deck[1];
    CommonCards[3] := Deck[2];
    CommonCards[4] := Deck[3];
    CommonCards[5] := Deck[4];

    HoleCards[1] := Deck[5];
    HoleCards[2] := Deck[6];
    HoleCards[3] := Deck[7];
    HoleCards[4] := Deck[8];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;

    showHand( Hand );
  end; { for }
end; { procedure btnRandomClick }


{ procedure TformMain.btnStraightFlushesClick
  Does: Generates the nine straight flushes
          in a single suit (in this case clubs).
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnStraightFlushesClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display straight flush hands }
  for count := caaClubAce to caaClubNine do
  begin
    CommonCards[1] := Deck[count];
    CommonCards[2] := Deck[count+3];
    CommonCards[3] := Deck[count+1];
    CommonCards[4] := Deck[count+16];
    CommonCards[5] := Deck[count+31];

    HoleCards[1] := Deck[count+15];
    HoleCards[2] := Deck[count+2];
    HoleCards[3] := Deck[count+29];
    HoleCards[4] := Deck[count+4];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;

  CommonCards[1] := Deck[caaHeartTen];
  CommonCards[2] := Deck[caaDiamondAce];
  CommonCards[3] := Deck[caaHeartQueen];
  CommonCards[4] := Deck[caaHeartKing];
  CommonCards[5] := Deck[caaDiamondFour];

  HoleCards[1] := Deck[caaHeartJack];
  HoleCards[2] := Deck[caaHeartAce];
  HoleCards[3] := Deck[caaDiamondTwo];
  HoleCards[4] := Deck[caaClubAce];

  { create Omaha Hand }
  Hand.HoleCards := HoleCards;
  Hand.CommonCards := CommonCards;
  showHand( Hand );
end; { procedure btnStraightFlushesClick }


{ procedure TformMain.btnFourOfAKindClick
  Does: Generates four of a kind hands. }
procedure TformMain.btnFourOfAKindClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display four of a kind hands }
  for count := caaClubAce to caaClubKing do
  begin
    CommonCards[1] := Deck[count+31];
    CommonCards[2] := Deck[count+32];
    CommonCards[3] := Deck[count];
    CommonCards[4] := Deck[count+1];
    CommonCards[5] := Deck[count+39];

    HoleCards[1] := Deck[count+26];
    HoleCards[2] := Deck[count+13];
    HoleCards[3] := Deck[count+15];
    HoleCards[4] := Deck[count+8];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnFourOfAKindClick }


{ procedure TformMain.btnFullHousesClick
  Does: Generates thirteen full houses.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnFullHousesClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display full house of a kind hands }
  for count := caaClubAce to caaClubKing do
  begin
    CommonCards[1] := Deck[count+23];
    CommonCards[2] := Deck[count+3];
    CommonCards[3] := Deck[count+9];
    CommonCards[4] := Deck[count];
    CommonCards[5] := Deck[count+16];

    HoleCards[1] := Deck[count+39];
    HoleCards[2] := Deck[count+6];
    HoleCards[3] := Deck[count+13];
    HoleCards[4] := Deck[count+40];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnFullHousesClick }


{ procedure TformMain.btnFlushesClick
  Does: Generates seven flushes.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnFlushesClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { create and display seven flushes }
  for count := caaClubAce to caaClubSeven do
  begin
    CommonCards[1] := Deck[count+23];
    CommonCards[2] := Deck[count];
    CommonCards[3] := Deck[count+4];
    CommonCards[4] := Deck[count+2];
    CommonCards[5] := Deck[count+16];

    HoleCards[1] := Deck[count+1];
    HoleCards[2] := Deck[count+6];
    HoleCards[3] := Deck[count+13];
    HoleCards[4] := Deck[count+40];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnFlushesClick }


{ procedure TformMain.btnStraightsClick
  Does:Generates straights.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnStraightsClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display straights }
 for count := caaClubAce to caaClubNine do
  begin
    CommonCards[1] := Deck[count+3];
    CommonCards[2] := Deck[count+15];
    CommonCards[3] := Deck[count+17];
    CommonCards[4] := Deck[count+1];
    CommonCards[5] := Deck[count+19];

    HoleCards[1] := Deck[count];
    HoleCards[2] := Deck[count+4];
    HoleCards[3] := Deck[count+18];
    HoleCards[4] := Deck[count+29];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnStraightsClick }


{ procedure TformMain.btnThreeOfAKindClick
  Does: Generates three of a kind hands using all thriteen ranks.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnThreeOfAKindClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display three of a kind hands }
  for count := caaClubAce to caaClubKing do
  begin
    CommonCards[1] := Deck[count+23];
    CommonCards[2] := Deck[count+3];
    CommonCards[3] := Deck[count+9];
    CommonCards[4] := Deck[count];
    CommonCards[5] := Deck[count+17];

    HoleCards[1] := Deck[count+39];
    HoleCards[2] := Deck[count+6];
    HoleCards[3] := Deck[count+13];
    HoleCards[4] := Deck[count+37];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnThreeOfAKindClick }


{ procedure TformMain.btnTwoPairClick
  Does: Generates two pair hands.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnTwoPairClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display two pair hands }
  for count := caaClubAce to caaClubKing do
  begin
    CommonCards[1] := Deck[count+23];
    CommonCards[2] := Deck[count+3];
    CommonCards[3] := Deck[count+9];
    CommonCards[4] := Deck[count];
    CommonCards[5] := Deck[count+16];

    HoleCards[1] := Deck[count+37];
    HoleCards[2] := Deck[count+6];
    HoleCards[3] := Deck[count+13];
    HoleCards[4] := Deck[count+28];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnTwoPairClick }


{ procedure TformMain.btnPairsClick
  Does: Generates thirteen single pair hands - one
          for each possible rank.
        Calls the showHand procedure to display each hand. }
procedure TformMain.btnPairsClick(Sender: TObject);
var
  HoleCards: TcaaOmahaHoleCardArray;
  CommonCards: Tcaa5CardArray;
  Hand: TcaaOmahaHand;
  Deck: TcaaCardDeck;
  count: integer;
begin
  { make sure display list box is empty }
  lbxDisplay.Clear;

  { build the deck }
  caaBuildCardDeck( Deck );

  { make sure display list box is empty }
  lbxDisplay.Clear;

  { display pairs }
  for count := caaClubAce to caaClubKing do
  begin
    CommonCards[1] := Deck[count+23];
    CommonCards[2] := Deck[count+3];
    CommonCards[3] := Deck[count+9];
    CommonCards[4] := Deck[count];
    CommonCards[5] := Deck[count+17];

    HoleCards[1] := Deck[count+37];
    HoleCards[2] := Deck[count+6];
    HoleCards[3] := Deck[count+13];
    HoleCards[4] := Deck[count+28];

    { create Omaha Hand }
    Hand.HoleCards := HoleCards;
    Hand.CommonCards := CommonCards;
    showHand( Hand );
  end;
end; { procedure btnPairsClick }

end.
