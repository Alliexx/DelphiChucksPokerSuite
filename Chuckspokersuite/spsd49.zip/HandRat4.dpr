program HandRat4;

(*
 * program HandRat4 for Delphi 4 through 2005 (32-Bit Native)
 * Copyright 2005, Charles A. Appel Jr.
 *)

uses
  Forms,
  RATHAND4 in 'RATHAND4.PAS' {frmRateHands},
  caaPSCrd in 'caaPSCrd.pas',
  caaPSDck in 'CAAPSDCK.PAS',
  caaPS4CH in 'CAAPS4CH.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrmRateHands, frmRateHands);
  Application.Run;
end.
