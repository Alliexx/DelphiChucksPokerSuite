program HandRat3;

(*
 * program HandRat3 for Delphi 4 through 2005 (32-Bit Native)
 * Copyright 2005, Charles A. Appel Jr.
 *)

uses
  Forms,
  RATHAND3 in 'RATHAND3.PAS' {frmRateHands},
  caaPSCrd in 'caaPSCrd.pas',
  caaPSDck in 'CAAPSDCK.PAS',
  caaPS3CH in 'CAAPS3CH.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrmRateHands, frmRateHands);
  Application.Run;
end.
