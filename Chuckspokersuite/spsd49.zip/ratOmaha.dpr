program ratOmaha;

(*
  Program mhrOmaha for Delphi 4 through 2005 (32-Bit Native)
  Copyright 2005, Charles A. Appel Jr.

  Purpose:
    Multi-hand rating utility using Omaha hands.
    Also demonstrates use of the caaOmaha.pas helper library.
 *)
 
uses
  Forms,
  ratOMain in 'ratOMain.pas' {formMain},
  caaOmaha in 'caaOmaha.pas',
  caaPSCrd in 'caaPSCrd.pas',
  caaPS5CH in 'CAAPS5CH.PAS',
  caaPSDck in 'CAAPSDCK.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TformMain, formMain);
  Application.Run;
end.
