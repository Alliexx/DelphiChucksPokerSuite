program vidpkr;

(*
 * program vidpkr for Delphi 4 through 2005 (32-Bit Native)
 * Copyright 2005, Charles A. Appel Jr.
 *)
  
uses
  Forms,
  vpkrmain in 'vpkrmain.pas' {formMain},
  caaPS5CH in 'CAAPS5CH.PAS',
  caaPSCrd in 'caaPSCrd.pas',
  caaPSDck in 'CAAPSDCK.PAS';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TformMain, formMain);
  Application.Run;
end.
